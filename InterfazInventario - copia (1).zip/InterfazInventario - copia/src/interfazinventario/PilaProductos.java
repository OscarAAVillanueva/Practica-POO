/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfazinventario;

/**
 *
 * @author FREDY
 */
public class PilaProductos {
     private Nodo cima;

    public PilaProductos() {
        cima = null;
    }

    public void apilar(Producto p) {
        Nodo nuevo = new Nodo(p);
        nuevo.siguiente = cima;
        cima = nuevo;
    }

    public void desapilar() {
        if (cima != null) {
            cima = cima.siguiente;
        }
    }

    public void mostrar() {
        Nodo actual = cima;
        while (actual != null) {
            Producto p = actual.dato;
            System.out.println("Código: " + p.getCodigo() +
                               " | Nombre: " + p.getNombre() +
                               " | Peso: " + p.getPeso());
            actual = actual.siguiente;
        }
    }
}

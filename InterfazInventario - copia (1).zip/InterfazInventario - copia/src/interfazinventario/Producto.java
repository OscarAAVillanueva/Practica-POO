/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfazinventario;

/**
 *
 * @author FREDY
 */
public class Producto {
    private String codigo;
    private String nombre;
    private double peso;
    private String tipoPeso;
    private String estadoStock;
    public Producto(String codigo, String nombre, double peso, String estadoStock) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.peso = peso;
        this.estadoStock = estadoStock;
        this.tipoPeso = (peso < 5) ? "Liviano" : "Pesado";
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public double getPeso() { return peso; }
    public String getEstadoStock() { return estadoStock; }
    public String getTipoPeso() {
    return tipoPeso;
    }
}
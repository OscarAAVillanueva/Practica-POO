/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfazinventario;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;  
/**
 *
 * @author FREDY
 */
   public class InterfazInventario extends JFrame {

    private final JTextField txtCodigo;
    private final JTextField txtNombre;
    private final JTextField txtPeso;
    private final JTextField txtBuscar;
    private final JButton btnAgregar;
    private final JButton btnEliminar;
    private final JButton btnBuscar;
    private final JButton btnCerrarSesion;
    private final JTable tabla;
    private final DefaultTableModel modeloTabla;
    private final ListaProductos lista;
    private final JRadioButton rbStockSi;
    private final JRadioButton rbStockNo;
    private final ButtonGroup grupoStock;

    private static Map<String, String> usuarios = new HashMap<>();

    public InterfazInventario() {
        super("Gestión de Inventario");

        if (!mostrarLogin()) {
            System.exit(0);
        }

        lista = new ListaProductos();

        setLayout(new BorderLayout());

        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelPrincipal.setBackground(Color.WHITE);

        JPanel panelBuscar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelBuscar.add(new JLabel("Buscar:"));
        txtBuscar = new JTextField(15);
        btnBuscar = new JButton("Buscar");
        btnCerrarSesion = new JButton("Cerrar Sesión");
        panelBuscar.add(txtBuscar);
        panelBuscar.add(btnBuscar);
        panelBuscar.add(btnCerrarSesion);
        panelPrincipal.add(panelBuscar);

        JPanel panelFormulario = new JPanel(new GridLayout(4, 2, 10, 10));
        panelFormulario.add(new JLabel("Código:"));
        txtCodigo = new JTextField(15);
        panelFormulario.add(txtCodigo);

        panelFormulario.add(new JLabel("Nombre:"));
        txtNombre = new JTextField(15);
        panelFormulario.add(txtNombre);

        panelFormulario.add(new JLabel("Peso (kg):"));
        txtPeso = new JTextField(15);
        panelFormulario.add(txtPeso);

        panelFormulario.add(new JLabel("Para Stock o Distribución:"));
        JPanel panelRadio = new JPanel(new FlowLayout(FlowLayout.LEFT));
        rbStockSi = new JRadioButton("Stock");
        rbStockNo = new JRadioButton("Distribución");
        grupoStock = new ButtonGroup();
        grupoStock.add(rbStockSi);
        grupoStock.add(rbStockNo);
        panelRadio.add(rbStockSi);
        panelRadio.add(rbStockNo);
        panelFormulario.add(panelRadio);

        panelPrincipal.add(panelFormulario);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        btnAgregar = new JButton("Agregar");
        btnEliminar = new JButton("Eliminar");
        panelBotones.add(btnAgregar);
        panelBotones.add(btnEliminar);
        panelPrincipal.add(panelBotones);

        modeloTabla = new DefaultTableModel(new Object[]{"Código", "Nombre", "Peso", "Stock", "Tipo"}, 0);
        tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);
        panelPrincipal.add(scrollPane);

        add(panelPrincipal);

        btnAgregar.addActionListener(e -> agregarProducto());
        btnEliminar.addActionListener(e -> eliminarProducto());
        btnBuscar.addActionListener(e -> buscarProducto());
        btnCerrarSesion.addActionListener(e -> cerrarSesion());

        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private boolean mostrarLogin() {
        JPanel panel = new JPanel(new GridLayout(4, 2));
        JTextField txtUsuario = new JTextField();
        JPasswordField txtContrasena = new JPasswordField();
        JButton btnRegistrar = new JButton("Registrarse");

        panel.add(new JLabel("Usuario:"));
        panel.add(txtUsuario);
        panel.add(new JLabel("Contraseña:"));
        panel.add(txtContrasena);
        panel.add(new JLabel("¿No tienes cuenta?"));
        panel.add(btnRegistrar);

        btnRegistrar.addActionListener(e -> {
            String usuario = txtUsuario.getText();
            String contrasena = new String(txtContrasena.getPassword());
            if (usuario.isEmpty() || contrasena.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Campos vacíos no válidos.");
                return;
            }
            if (usuarios.containsKey(usuario)) {
                JOptionPane.showMessageDialog(null, "El usuario ya está registrado.");
            } else {
                usuarios.put(usuario, contrasena);
                JOptionPane.showMessageDialog(null, "Usuario registrado exitosamente.");
            }
        });

        Object[] options = {"Iniciar sesión", "Salir"};
        int opcion = JOptionPane.showOptionDialog(null, panel, "Inicio de sesión",
                JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, options, options[0]);

        if (opcion == JOptionPane.YES_OPTION) {
            String usuario = txtUsuario.getText();
            String contrasena = new String(txtContrasena.getPassword());

            if (usuarios.containsKey(usuario)) {
                if (usuarios.get(usuario).equals(contrasena)) {
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "Contraseña incorrecta.");
                    return mostrarLogin();
                }
            } else {
                JOptionPane.showMessageDialog(null, "Usuario no registrado.");
                return mostrarLogin();
            }
        } else {
            return false;
        }
    }

    private void cerrarSesion() {
        dispose();
        SwingUtilities.invokeLater(() -> new InterfazInventario());
    }

    private void agregarProducto() {
        String codigo = txtCodigo.getText().trim();
        String nombre = txtNombre.getText().trim();
        double peso;
        String estadoStock;

        if (codigo.isEmpty() || nombre.isEmpty() || txtPeso.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Completa todos los campos.");
            return;
        }

        if (lista.existeProducto(codigo)) {
            JOptionPane.showMessageDialog(this, "El código ya está registrado.");
            return;
        }

        try {
            peso = Double.parseDouble(txtPeso.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Peso inválido.");
            return;
        }

        if (rbStockSi.isSelected()) {
            estadoStock = "Sí";
        } else if (rbStockNo.isSelected()) {
            estadoStock = "No";
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona si está en stock o no.");
            return;
        }

        Producto p = new Producto(codigo, nombre, peso, estadoStock);
        lista.agregar(p);
        actualizarTabla();
        limpiarCampos();
    }

    private void eliminarProducto() {
        String codigo = txtCodigo.getText().trim();
        if (codigo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingresa el código a eliminar.");
            return;
        }

        lista.eliminar(codigo);
        actualizarTabla();
        limpiarCampos();
    }

    private void buscarProducto() {
        String texto = txtBuscar.getText().trim();
        if (texto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingresa un código o nombre para buscar.");
            return;
        }

        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            String cod = modeloTabla.getValueAt(i, 0).toString();
            String nom = modeloTabla.getValueAt(i, 1).toString();

            if (cod.equalsIgnoreCase(texto) || nom.equalsIgnoreCase(texto)) {
                tabla.setRowSelectionInterval(i, i);
                tabla.scrollRectToVisible(tabla.getCellRect(i, 0, true));
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "Producto no encontrado.");
    }

    private void actualizarTabla() {
        lista.mostrarEnTabla(modeloTabla);
    }

    private void limpiarCampos() {
        txtCodigo.setText("");
        txtNombre.setText("");
        txtPeso.setText("");
        grupoStock.clearSelection();
        txtBuscar.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InterfazInventario());
    }
}
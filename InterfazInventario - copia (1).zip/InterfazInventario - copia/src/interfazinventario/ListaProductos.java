/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfazinventario;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author FREDY
 */
public class ListaProductos {
    private Nodo cabeza;

    public ListaProductos() {
        cabeza = null;
    }

    public void agregar(Producto p) {
        Nodo nuevo = new Nodo(p);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo aux = cabeza;
            while (aux.siguiente != null) {
                aux = aux.siguiente;
            }
            aux.siguiente = nuevo;
        }
    }

    public void eliminar(String codigo) {
        if (cabeza == null) return;

        if (cabeza.dato.getCodigo().equalsIgnoreCase(codigo)) {
            cabeza = cabeza.siguiente;
            return;
        }

        Nodo actual = cabeza;
        while (actual.siguiente != null && !actual.siguiente.dato.getCodigo().equalsIgnoreCase(codigo)) {
            actual = actual.siguiente;
        }

        if (actual.siguiente != null) {
            actual.siguiente = actual.siguiente.siguiente;
        }
    }

    public void mostrarEnTabla(DefaultTableModel modelo) {
        modelo.setRowCount(0);
    Nodo aux = cabeza;
    while (aux != null) {
        Producto p = aux.dato;
        modelo.addRow(new Object[]{
        p.getCodigo(), 
        p.getNombre(), 
        p.getPeso(),
        p.getEstadoStock(), 
        p.getTipoPeso()
        });
        aux = aux.siguiente;
    }
    }
    public boolean existeProducto(String codigo) {
    Nodo aux = cabeza;
    while (aux != null) {
        if (aux.dato.getCodigo().equalsIgnoreCase(codigo)) {
            return true;
        }
        aux = aux.siguiente;
    }
    return false;
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfazinventario;

/**
 *
 * @author FREDY
 */
public class Nodo {
    public Producto dato;
    public Nodo siguiente;

    public Nodo(Producto dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}

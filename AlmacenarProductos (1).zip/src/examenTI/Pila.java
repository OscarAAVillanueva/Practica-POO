package examenTI;

public class Pila {
    private Nodo cima;

    public void apilar(AlmacenarProductos producto) {
        Nodo nuevo = new Nodo(producto);
        nuevo.siguiente = cima;
        cima = nuevo;
    }

    public AlmacenarProductos desapilar() {
        if (cima == null) return null;

        AlmacenarProductos producto = cima.datos;
        cima = cima.siguiente;
        return producto;
    }

    public boolean estaVacia() {
        return cima == null;
    }
}
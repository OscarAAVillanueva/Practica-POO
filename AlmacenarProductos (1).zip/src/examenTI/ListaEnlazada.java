package examenTI;

public class ListaEnlazada {
    private Nodo inicial;

    public void agregar(AlmacenarProductos producto) {
        Nodo nuevo = new Nodo(producto);
        if (inicial == null) {
            inicial = nuevo;
        } else {
            Nodo actual = inicial;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
        }
    }

    public void mostrar() {
        Nodo actual = inicial;
        while (actual != null) {
            actual.datos.mostrarInformacion();
            actual = actual.siguiente;
        }
    }

    public AlmacenarProductos buscar(String codigo) {
        Nodo actual = inicial;
        while (actual != null) {
            if (actual.datos.getCodigo().equals(codigo)) {
                return actual.datos;
            }
            actual = actual.siguiente;
        }
        return null;
    }
}
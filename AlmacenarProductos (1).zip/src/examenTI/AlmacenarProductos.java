package examenTI;

public class AlmacenarProductos {
    private String codigo;
    private String descripcion;
    private double peso;

    public AlmacenarProductos(String codigo, String descripcion, double peso) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.peso = peso;
    }

    public String getCodigo() {
        return codigo;
    }

    public double getPeso() {
        return peso;
    }

    public void mostrarInformacion() {
        System.out.println("Código: " + codigo + " Descripción: " + descripcion + " Peso: " + peso + " kg");
    }
}
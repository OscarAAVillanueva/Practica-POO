package examenTI;

public class Nodo {
    public AlmacenarProductos datos;
    public Nodo siguiente;

    public Nodo(AlmacenarProductos datos) {
        this.datos = datos;
        this.siguiente = null;
    }
}
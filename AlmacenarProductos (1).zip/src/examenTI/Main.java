package examenTI;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Pila pila = new Pila();
        ListaEnlazada listaGrandes = new ListaEnlazada();
        ListaEnlazada listaPequeños = new ListaEnlazada();

        int opcion;
        do {
            System.out.println("Seleccione una opción: ");
            System.out.println("1. Registrar nuevos productos");
            System.out.println("2. Realizar inventario del día");
            System.out.println("3. Mostrar productos grandes");
            System.out.println("4. Mostrar productos pequeños");
            System.out.println("5. Buscar producto en inventario");
            System.out.println("6. Inventario final de productos");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el código del producto: ");
                    String codigo = scanner.nextLine();
                    System.out.print("Ingrese el tipo de producto: ");
                    String descripcion = scanner.nextLine();
                    System.out.print("Ingrese el peso del producto (kg): ");
                    double peso = Double.parseDouble(scanner.nextLine());
                    AlmacenarProductos nuevoProducto = new AlmacenarProductos(codigo, descripcion, peso);
                    pila.apilar(nuevoProducto);
                    break;

                case 2:
                    while (!pila.estaVacia()) {
                        AlmacenarProductos producto = pila.desapilar();
                        if (producto.getPeso() > 10) {
                            listaGrandes.agregar(producto);
                        } else {
                            listaPequeños.agregar(producto);
                        }
                    }
                    System.out.println("El inventario se realizó exitosamente.");
                    break;

                case 3:
                    System.out.println("Inventario de productos grandes:");
                    listaGrandes.mostrar();
                    break;

                case 4:
                    System.out.println("Inventario de productos pequeños:");
                    listaPequeños.mostrar();
                    break;

                case 5:
                    System.out.print("Ingrese el código del producto a buscar: ");
                    String codigoBuscar = scanner.nextLine();
                    AlmacenarProductos encontrado = listaGrandes.buscar(codigoBuscar);
                    if (encontrado == null) {
                        encontrado = listaPequeños.buscar(codigoBuscar);
                    }
                    if (encontrado != null) {
                        System.out.println("Producto encontrado:");
                        encontrado.mostrarInformacion();
                    } else {
                        System.out.println("Producto NO encontrado.");
                    }
                    break;

                case 6:
                    System.out.println("Inventario final de productos:");
                    listaGrandes.mostrar();
                    listaPequeños.mostrar();
                    break;

                case 0:
                    System.out.println("Programa cerrado.");
                    break;

                default:
                    System.out.println("Opción inválida.");
                    break;
            }

            System.out.println();
        } while (opcion != 0);

        scanner.close();
    }
}